package com.mindgate.main.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.TravelDetails;
import com.mindgate.main.pojo.TravellingRequestDetails;
import com.mindgate.main.repository.TravelDetailsRepositoryInterface;
import com.mindgate.main.repository.TravlingRequestDetailsRepositoryInterface;


@Service
public class TravlingRequestDetailsService implements TravlingRequestDetailsServiceInterface {
	@Autowired
	private TravlingRequestDetailsRepositoryInterface travlingRequestDetailsRepositoryInterface;
	

	@Autowired
	private TravelDetailsRepositoryInterface travelDetailsRepositoryInterface;
	
	
	@Override
	public boolean addTravellingRequestDetails(TravellingRequestDetails travellingRequestDetails) {
		
		return travlingRequestDetailsRepositoryInterface.addTravellingRequestDetails(travellingRequestDetails);
	}

	@Override
	public TravellingRequestDetails getTravellingRequestDetailsBytravelRequestId(int travelRequestId) {
		return travlingRequestDetailsRepositoryInterface.getTravellingRequestDetailsBytravelRequestId(travelRequestId);
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestDetails() {
		return travlingRequestDetailsRepositoryInterface.getAllTravellingRequestDetails();
	}

	

	@Override
	public boolean updateTravellingRequestDetailsByTravelRequestId(TravellingRequestDetails travellingRequestDetails) {
		return travlingRequestDetailsRepositoryInterface.updateTravellingRequestDetailsBytravelRequestId(travellingRequestDetails);
	}

	

	@Override
	public boolean updateManagerStatusByTravelRequestId(TravellingRequestDetails travellingRequestDetails) {
		return travlingRequestDetailsRepositoryInterface.updateManagerStatusBytravelRequestId(travellingRequestDetails);
	}

	
	@Override
	public boolean updateDirectorStatusByTravelRequestId(TravellingRequestDetails travellingRequestDetails) {
		return travlingRequestDetailsRepositoryInterface.updateDirectorStatusBytravelRequestId(travellingRequestDetails);
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestDetailsByEmployeeId(int employeeId) {
		return travlingRequestDetailsRepositoryInterface.getAllTravellingRequestDetailsByEmployeeId(employeeId);
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestDetailsForaAgent() {
		return getAllTravellingRequestDetailsForAgent();
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestDetailsForAgent() {
		
		return travlingRequestDetailsRepositoryInterface.getAllTravellingRequestDetailsForAgent();
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestByManagerId(int managerId) {
		return travlingRequestDetailsRepositoryInterface.getAllTravellingRequestByManagerId(managerId);
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingPendingRequestByManagerId(int managerId) {
		return travlingRequestDetailsRepositoryInterface.getAllTravellingPendingRequestByManagerId(managerId);
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingAcceptRequestByManagerId(int managerId) {
		return travlingRequestDetailsRepositoryInterface.getAllTravellingAcceptRequestByManagerId(managerId);
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingRejectedRequestByManagerId(int managerId) {
		return travlingRequestDetailsRepositoryInterface.getAllTravellingRejectedRequestByManagerId(managerId);
	}

	@Override
	public List<TravellingRequestDetails> getAllTravellingRequestDetailsForDirector() {
		return travlingRequestDetailsRepositoryInterface.getAllTravellingRequestDetailsForDirector();
	}

	@Override
	public List<TravellingRequestDetails> getAllAcceptedTravellingRequestDetailsForAgent() {
		return travlingRequestDetailsRepositoryInterface.getAllAcceptedTravellingRequestDetailsForAgent();
	}
	

	@Override
	public boolean insertTravalDetails(TravellingRequestDetails travellingRequestDetails) {
		
	TravelDetails travelDetails = travellingRequestDetails.getTravelDetails();

	TravellingRequestDetails loadedTravelingRequestDetails =  travlingRequestDetailsRepositoryInterface.getTravellingRequestDetailsBytravelRequestId(travellingRequestDetails.getTravelRequestId());
	
	loadedTravelingRequestDetails.setTravelDetails(travelDetails);
	
	return	(travelDetailsRepositoryInterface.addTravelDetails(loadedTravelingRequestDetails.getTravelDetails()) && travlingRequestDetailsRepositoryInterface.insertTravalDetails(loadedTravelingRequestDetails));
		
		
	}

	@Override
	public List<TravellingRequestDetails> getAllApprovedTravellingRequestForTravelAgent() {
		return travlingRequestDetailsRepositoryInterface.getAllApprovedTravellingRequestForTravelAgent();
	}

	@Override
	public List<TravellingRequestDetails> getPendingTravellingRequestForTravelAgent() {
		return travlingRequestDetailsRepositoryInterface.getPendingTravellingRequestForTravelAgent();
	}

	
	
	
	

//	@Override
//	public boolean updateTravellingRequestDetailsBytravelRequestId(TravellingRequestDetails travellingRequestDetails) {
//		return travlingRequestDetailsRepositoryInterface
//				.updateTravellingRequestDetailsBytravelRequestId(travellingRequestDetails);
//	}
//
//	@Override
//	public boolean deleteTravellingRequestDetailsBytravelRequestId(int travelRequestId) {
//		return travlingRequestDetailsRepositoryInterface.deleteTravellingRequestDetailsBytravelRequestId(travelRequestId);
//	}


}
